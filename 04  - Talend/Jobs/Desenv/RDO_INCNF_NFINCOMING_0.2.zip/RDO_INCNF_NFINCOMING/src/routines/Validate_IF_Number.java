package routines;

public class Validate_IF_Number {

	
	static public boolean is_number(String number,int comprimento_minimo){
		
		if(number.length() < comprimento_minimo){			
			return false;
		}
		
		int x = 0;
		
		for ( int i = 0 ; i < number.length(); i++ ){
			try{
				x = Integer.parseInt(String.valueOf(number.charAt(i)));
			}catch(Exception e){
				return false;
			}
		}
		

		return true;
	}
	
	
}
