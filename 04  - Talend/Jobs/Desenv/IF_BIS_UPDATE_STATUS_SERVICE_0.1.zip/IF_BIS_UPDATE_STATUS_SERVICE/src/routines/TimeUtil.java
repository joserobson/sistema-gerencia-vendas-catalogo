package routines;

import java.util.Calendar;
import java.util.Date;


public class TimeUtil {

      
    /**
     * @param iMinutes
     * @param lDate
     * @return
     */
    public static Long addMinutes(Integer iMinutes, Long lDate){
    	Long ret = new Date().getTime();
    	if(iMinutes != null){
    		if(lDate == null){
    			lDate = new Date().getTime();
    		}
    		Calendar cal = Calendar.getInstance();
    		cal.setTime(new Date(lDate));
    		cal.add(Calendar.MINUTE, iMinutes);
    		ret = cal.getTimeInMillis();
    	}
    	return ret;
    }
    
    public static Integer compareDateLimit (Date dtTarget, Integer iMinutes, Integer iGmt){
    	Integer ret = null;
    	
    	if((dtTarget != null && dtTarget.getTime() > 0L) && (iMinutes != null && iMinutes > 0)){
    		if(iGmt == null){
    			iGmt = 0;
    		}
    		Calendar cal = Calendar.getInstance();
    		cal.add(Calendar.HOUR, iGmt);
    		cal.add(Calendar.MINUTE, (iMinutes * -1));
    		ret = dtTarget.compareTo(cal.getTime());
    	}
    	
    	return ret;
    }
}
